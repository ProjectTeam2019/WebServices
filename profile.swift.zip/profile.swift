//
//  profile.swift
//  ProjectDemo
//
//  Created by MAC2 on 09/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import GoogleSignIn

class profile: UIViewController,UITableViewDelegate,UITableViewDataSource,CAAnimationDelegate {
    
    var tbl = UITableView()
    var hidemenu:Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tbl = UITableView(frame: CGRect(x: 0, y: 0, width: 0, height: self.view.frame.size.height), style: .grouped)
        tbl.dataSource = self
        tbl.delegate = self
        let right = UISwipeGestureRecognizer(target: self, action: #selector(self.showmenu))
        let left = UISwipeGestureRecognizer(target: self, action: #selector(self.hide))
        left.direction = .left
        right.direction = .right
        self.view.addGestureRecognizer(right)
        self.view.addGestureRecognizer(left)
        self.view.addSubview(tbl)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hide()
    }
    
    @IBAction func btnitem(_ sender: Any)
    {
        if hidemenu == true
        {
            showmenu()
        }
        else
        {
            hide()
        }
    }
    func hide() {
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: 0, y: 0, width: 0, height: self.view.frame.size.height)
        UIView.commitAnimations()
        hidemenu = true
    }
    
    func showmenu()  {
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width/1.3, height: self.view.frame.size.height)
        UIView.commitAnimations()
        hidemenu = false
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        if indexPath.row == 4 {
            cell.textLabel?.text = "Logout"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 4
        {
            GIDSignIn.sharedInstance().signOut()
            let diff = UserDefaults.standard
            diff.removeObject(forKey: "Username")
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "cdr")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: 0, y: 0, width: 0, height: self.view.frame.size.height)
        UIView.commitAnimations()
    }
    
    
}
