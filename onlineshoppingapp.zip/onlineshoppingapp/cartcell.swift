//
//  cartcell.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 10/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class cartcell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var Total: UILabel!
    @IBOutlet weak var stppr: UIStepper!
    @IBOutlet weak var p_price: UILabel!
    @IBOutlet weak var qty: UILabel!
    @IBOutlet weak var p_name: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
