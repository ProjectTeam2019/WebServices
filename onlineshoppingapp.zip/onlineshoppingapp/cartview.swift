//
//  cartview.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 05/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class cartview: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var Grand_Total: UIButton!
    var arr : [Any] = []
   
    
    @IBOutlet weak var tblv: UITableView!
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! cartcell
        
        let ar1 = arr[indexPath.row]as! [String]
        cell.img.image = UIImage(named: ar1[3])
        cell.p_name.text = ar1[1]
        cell.p_price.text = ar1[2]
        cell.qty.text = ar1[4]
        cell.Total.text = ar1[2]
        cell.stppr.addTarget(self, action: #selector(self.step), for: .valueChanged)
        cell.stppr.tag = indexPath.row
        return cell
    }
    
    @objc func step(sender:UIStepper) {
        let indexpath = IndexPath(row: sender.tag, section: 0)
        
        let cell = tblv.cellForRow(at: indexpath)as! cartcell
        cell.qty.text = String(sender.value)
        
        
        var price = Int(cell.p_price.text!)
        var qty1 = Int(sender.value)
        var total = price! * qty1
         cell.Total.text = String(total)
        var sum : Int = 0
        for i in 0...arr.count - 1
        {
            let indexpath = IndexPath(row: i, section: 0)
        
            let cell = tblv.cellForRow(at: indexpath)as! cartcell
            let grd = Int(cell.Total.text!)
            sum = sum + grd!
            
            
            
        }
        
        Grand_Total.titleLabel?.text = "Grand Total = \(sum)"

        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func ProcedOrder(_ sender: Any) {
    }
    @IBAction func GrandTotal(_ sender: Any) {
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let db = dbclass();
        
        let strquery = "select * from tblcart";
        
        arr = db.getdata(strquery: strquery)
        print(arr)
        tblv.reloadData();
       // let arr
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
