//
//  detailscusttabcell2.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 17/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class detailscusttabcell2: UITableViewCell {

    @IBOutlet weak var collimges: UICollectionView!
    @IBOutlet weak var detalcoll: UICollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
