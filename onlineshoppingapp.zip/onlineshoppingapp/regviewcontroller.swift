//
//  regviewcontroller.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 02/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class regviewcontroller: UIViewController {

    @IBOutlet weak var v2login: UIView!
    @IBOutlet weak var lognalready: UIButton!
    @IBOutlet weak var newac: UIButton!
    @IBOutlet weak var txtpass: UITextField!
    @IBOutlet weak var txtmail: UITextField!
    @IBOutlet weak var txtpin: UITextField!
    @IBOutlet weak var txtmob: UITextField!
    @IBOutlet weak var txtname: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        v1.isHidden = true
        v2login.isHidden = true
        newac.clipsToBounds = true
        newac.layer.cornerRadius = newac.frame.width/2
        lognalready.clipsToBounds = true
        lognalready.layer.cornerRadius = lognalready.frame.width/2
      
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var v1: UIView!
    
   
    @IBAction func btnregistration(_ sender: Any) {
        
        let url = URL(string: "http://localhost/onlineshop/reg.php");
        
        let strbody = "username=\(txtname.text!)&password=\(txtpass.text!)&email=\(txtmail.text!)&pincode=\(txtpin.text!)&mobno=\(txtmob.text!)";
        
        var request = URLRequest(url: url!);
        request.addValue(String(strbody.count), forHTTPHeaderField: "Content-Length");
        request.httpBody = strbody.data(using: String.Encoding.utf8);
        request.httpMethod = "POST";
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            DispatchQueue.main.async {
                
                let strresp = String(data: data1!, encoding: String.Encoding.utf8);
                
                
                if  strresp == "Inserted"
                {
                    
                    let alt = UIAlertController(title: "Message", message: "Successfully Register", preferredStyle: .alert);
                    
                    let ok = UIAlertAction(title: "Ok", style: .default, handler: { (act) in
                        
                        let login = self.storyboard?.instantiateViewController(withIdentifier: "login");
                        
                        self.navigationController?.pushViewController(login!, animated: true);
                        
                        
                        
                        
                        
                        
                    })
                    
                    alt.addAction(ok);
                    
                    self.present(alt, animated: true, completion: nil);
                    
                    
                }
                else
                {
                    
                    
                }
                
                
                
            }
            
            
            
            
        }
        
        datatask.resume();
        
        
        
        
        
    }
    
    @IBAction func checkloginald(_ sender: Any) {
        v2login.frame = CGRect(x: 67, y: 200, width: 240, height: 128)
        lognalready.setImage(UIImage(named: "check.png"), for: .normal)
       newac.imageView?.isHidden = true
         v1.isHidden = true
        v2login.isHidden = false
        v2login.layer.cornerRadius = 20
        v2login.clipsToBounds = true
        self.view.addSubview(v2login)
    }
    @IBAction func checknewact(_ sender: Any) {
        
         v1.isHidden = false
        v1.frame = CGRect(x: 14, y: 200, width: 346, height: 347)
        v1.layer.cornerRadius = 20
        v1.clipsToBounds = true
      newac.setImage(UIImage(named: "check.png"), for: .normal)
        lognalready.imageView?.isHidden = true
        v2login.isHidden = true
        self.view.addSubview(v1)
        
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
