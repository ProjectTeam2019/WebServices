//
//  wishlistcollcell.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 24/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class wishlistcollcell: UICollectionViewCell {
    
    @IBOutlet weak var delete: UIButton!
    @IBOutlet weak var wishlistprice: UILabel!
    @IBOutlet weak var wishlistpname: UILabel!
    @IBOutlet weak var wishlistimgs: UIImageView!
}
