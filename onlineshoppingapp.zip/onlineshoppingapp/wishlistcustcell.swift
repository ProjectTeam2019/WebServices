//
//  wishlistcustcell.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 24/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class wishlistcustcell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var wishlistcoll: UICollectionView!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
