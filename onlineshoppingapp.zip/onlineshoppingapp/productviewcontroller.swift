//
//  productviewcontroller.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 15/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"




class productviewcontroller: UICollectionViewController {
    
    let productimg = [["prodimg":"product1.jpeg","prodname":"sport","prodprice":"600","p_id":"1"],
                      ["prodimg":"product2.jpeg","prodname":"sport","prodprice":"600","p_id":"2"],
                      ["prodimg":"product3.jpeg","prodname":"sport","prodprice":"600","p_id":"3"],
                      ["prodimg":"product4.jpeg","prodname":"sport","prodprice":"600","p_id":"4"],
                      ["prodimg":"product5.jpeg","prodname":"sport","prodprice":"600","p_id":"5"],
                      ["prodimg":"product6.jpeg","prodname":"sport","prodprice":"600","p_id":"6"],
                      ["prodimg":"product7.jpeg","prodname":"sport","prodprice":"600","p_id":"7"],
                      ["prodimg":"product8.jpeg","prodname":"sport","prodprice":"600","p_id":"8"],
                      ["prodimg":"product9.jpeg","prodname":"sport","prodprice":"600","p_id":"9"],
                      ["prodimg":"product10.png","prodname":"sport","prodprice":"600","p_id":"10"]]
                      
    let obj = commonfile()
    
    var arr : [Any] = []
    
    var imge :[String : Any] = [:]
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
        

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)

        // Do any additional setup after loading the view.
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return productimg.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "coll", for: indexPath)as! productcollcell
        let dic = productimg[indexPath.row]
        cell.proimg.image = UIImage(named: dic["prodimg"]!)
        cell.proname.text = dic["prodname"]
        cell.proprice.text = dic["prodprice"]
        cell.layer.borderColor = UIColor.darkGray.cgColor
        cell.layer.borderWidth = 1
        
        let btn = UIButton(type: .custom)
        btn.frame = CGRect(x: cell.frame.size.width - 30, y: 0, width: 25, height: 25)
        //btn.layer.borderWidth = 1
        btn.tag = indexPath.row
        print(btn.tag)
       btn.setImage(UIImage(named: "heart-128"), for: .normal)
        btn.addTarget(self, action: #selector(self.wishlist), for: .touchUpInside)
        
    cell.addSubview(btn)
        // Configure the cell
    
        return cell
    }
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let st = self.storyboard?.instantiateViewController(withIdentifier: "details")as! detailsviewcontroller
         st.imge = productimg[indexPath.row]
        
        self.navigationController?.pushViewController(st, animated: true)
    }
    
    @objc func wishlist(sender:UIButton)  {
        
       imge  = productimg[sender.tag]
     let alt  = UIAlertController(title: "", message: "WishList", preferredStyle: .alert)
        let ok = UIAlertAction(title: "ok", style: .default) { (test) in
               sender.setImage(UIImage(named: "wish.png"), for: .normal)
            let db = dbclass();
            
            let p_id = self.imge["p_id"];
            let p_name = self.imge["prodname"];
            let p_price = self.imge["prodprice"];
            let p_imge = self.imge["prodimg"];
            
            let strquery = "insert into wishtbl(w_id,w_name,w_price,w_image)values('\(p_id!)','\(p_name!)','\(p_price!)','\(p_imge!)')";
            
            let st = db.dml(strquery: strquery);
            if st == true {
                
                print("item added wish");
                
            }
            else
                
            {
                print("item not  added in wish");
                
            }
            
            
            
            
        }
        //code to add wishlist
            
            
            
        
        let cancel = UIAlertAction(title: "cancel", style: .default) { (test) in
            sender.setImage(UIImage(named: "heart-128"), for: .normal)
        }
        
        alt.addAction(ok)
        alt.addAction(cancel)
       self.present(alt, animated: true, completion: nil)
         arr.append(productimg[sender.tag])
        print(sender.tag)
        //let path = getpath()
        let path = obj.getpath()
      print(path)
        let ar = NSMutableArray(contentsOfFile: path)
        //print(ar!)
        
        let finaldic = NSMutableArray(array: arr)
       // finaldic.write(toFile: getpath(), atomically: true)
           finaldic.write(toFile:obj.getpath(), atomically: true)
        print(finaldic)
        
        
        }
    
    
    
    
    
    
   /* func getpath() -> String{
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let str = path[0]
        let fulpath = str.appending("/wish.plist")
        print(fulpath)
        return fulpath
        
    }*/
    

    
    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */

    
    
    
    
}
