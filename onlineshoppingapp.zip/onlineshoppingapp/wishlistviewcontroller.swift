//
//  wishlistviewcontroller.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 24/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class wishlistviewcontroller: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource{
   
    
   var arr : [Any] = []
    var prod1 : [String] = []
   var  prod2: [String] = []
    var prod3 : [String] = []
    let obj = commonfile()
    var prod : [String:String] = [:]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let path = obj.getpath()
        
        let ar = NSArray(contentsOfFile: path)
        print(ar!)
        
        //let finaldic = NSMutableArray(array: arr)
        // finaldic.write(toFile: getpath(), atomically: true)
        //finaldic.write(toFile:obj.getpath(), atomically: true)
        prod1 = ar!.value(forKey: "prodimg") as! [String]
        prod2 = ar!.value(forKey: "prodname") as! [String]
        prod3 = ar?.value(forKey: "prodprice") as! [String]
        
       // tabBarController?.selectedIndex = 5

        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! wishlistcustcell
        cell.wishlistcoll.reloadData()
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return prod1.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "coll", for: indexPath)as! wishlistcollcell
     cell.wishlistimgs.image = UIImage(named:prod1[indexPath.row] )
        cell.wishlistpname.text = prod2[indexPath.row]
        cell.wishlistprice.text = prod3[indexPath.row]
        
       
        return cell
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 150
        
    }
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
