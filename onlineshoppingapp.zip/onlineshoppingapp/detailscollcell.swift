//
//  detailscollcell.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 17/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class detailscollcell: UICollectionViewCell {
    
    @IBOutlet weak var collimg: UIImageView!
}
