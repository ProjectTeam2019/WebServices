//
//  detailcusttabcell3.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 18/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class detailcusttabcell3: UITableViewCell {

    @IBOutlet weak var wishlistbt: UIButton!
    @IBOutlet weak var share: UIButton!
    @IBOutlet weak var imgoff: UIImageView!
    @IBOutlet weak var offprice: UILabel!
    @IBOutlet weak var tax: UILabel!
    @IBOutlet weak var freedelivery: UILabel!
    @IBOutlet weak var specialprice: UILabel!
    @IBOutlet weak var prodprice: UILabel!
    @IBOutlet weak var prodname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
