//
//  detailsviewcontroller.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 17/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit


class detailsviewcontroller: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource {

var time = Timer()
    var a = 0
    @IBOutlet weak var tbl: UITableView!
    
    @IBOutlet weak var addcart: UIButton!
    
    @IBOutlet weak var buynow: UIButton!
    let productimg = [["prodimg":"product1.jpeg","prodname":"sport","prodprice":"600","p_id":"1"],
                      ["prodimg":"product2.jpeg","prodname":"sport","prodprice":"600","p_id":"2"],
                      ["prodimg":"product3.jpeg","prodname":"sport","prodprice":"600","p_id":"3"],
                      ["prodimg":"product4.jpeg","prodname":"sport","prodprice":"600","p_id":"4"],
                      ["prodimg":"product5.jpeg","prodname":"sport","prodprice":"600","p_id":"5"],
                      ["prodimg":"product6.jpeg","prodname":"sport","prodprice":"600","p_id":"6"],
                      ["prodimg":"product7.jpeg","prodname":"sport","prodprice":"600","p_id":"7"],
                      ["prodimg":"product8.jpeg","prodname":"sport","prodprice":"600","p_id":"8"],
                      ["prodimg":"product9.jpeg","prodname":"sport","prodprice":"600","p_id":"9"],
                      ["prodimg":"product10.png","prodname":"sport","prodprice":"600","p_id":"10"]]
    
    
    var imge : [String:Any] = [:]
    var obj = commonfile()
    var arr : [String] = []
    var wishl : [String:String] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
        craetesrc()
        
        // Do any additional setup after loading the view.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0
        {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)as! detailscusttabcell
            cell.detailsimg.image = UIImage(named: imge["prodimg"] as! String)
        
       // cell.detailimg.image = UIImage(named: imgv["prodimg"] as! String)
        return cell
        }
        else if indexPath.section == 1
        {
              let cell = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath)as! detailscusttabcell2
         cell.collimges.reloadData()
            
            return cell
        }
        else if indexPath.section == 2
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell3", for: indexPath)as! detailcusttabcell3
            cell.wishlistbt.addTarget(self, action: #selector(self.wish), for:.touchUpInside)
            
            return cell
        }
        else if indexPath.section == 3
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell4", for: indexPath)as! detailcusttabcell4
           
            
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell5", for: indexPath)as! detailcusttabcell5
            
            
            return cell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0
        {
            return 180
        }
        else  if indexPath.section == 1
        {
            return 150
        }
        else  if indexPath.section == 2
        {
            return 250
        }
        else  if indexPath.section == 3
        {
            return 80
        }
        else  
        {
            return 150
        }
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return productimg.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "coll", for: indexPath)as! detailscollcell
        let dic = productimg[indexPath.row]
        
        cell.collimg.image = UIImage(named: dic["prodimg"]!)
       UICollectionView.beginAnimations(nil, context: nil)
        UICollectionView.setAnimationDuration(0.1)
            UICollectionView.commitAnimations()
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        imge = productimg[indexPath.row]
        tbl.reloadData()
    }
    func craetesrc()  {
        
        let src = UIScrollView()
        src.frame = self.view.frame
        src.contentSize = CGSize(width: self.view.frame.width, height: 1000)
        self.view.addSubview(src)
        src.addSubview(tbl)
        src.addSubview(addcart)
        src.addSubview(buynow)
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.isEditing = true
    }
    
    @IBAction func addtocartbtn(_ sender: Any) {
    
        let db = dbclass();
        
        let p_id = imge["p_id"];
        let p_name = imge["prodname"];
        let p_price = imge["prodprice"];
        let p_imge = imge["prodimg"];
        
        let strquery = "insert into tblcart(p_id,p_name,p_price,p_img,qty)values('\(p_id!)','\(p_name!)','\(p_price!)','\(p_imge!)','1')";
        
        let st = db.dml(strquery: strquery);
        if st == true {
            
            print("item added in cart");
            
        }
        else
        
        {
             print("item not  added in cart");
            
        }
        
        
       
    
    }
    
    
    @objc func wish(sender:UIButton)  {
        
        let st = self.storyboard?.instantiateViewController(withIdentifier: "wishlist")as! wishlistviewcontroller
        
       
        
        self.navigationController?.pushViewController(st, animated: true)
       
    }
  

    
    
    @IBAction func buynowbtn(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
