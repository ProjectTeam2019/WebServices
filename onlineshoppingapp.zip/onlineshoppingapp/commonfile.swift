//
//  commonfile.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 05/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class commonfile: NSObject {

    func createnav(fram:CGRect) -> UINavigationBar {
        let navbar = UINavigationBar()
        navbar.frame = fram
        
     
        return navbar
    }
    
    func images(fram:CGRect) -> UIImageView{
        let ima = UIImageView()
        ima.frame = fram
        return ima
        
    }
    func getpath() -> String{
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let str = path[0]
        let fulpath = str.appending("/wish.plist")
        print(fulpath)
        return fulpath
        
    }
    

    
}
