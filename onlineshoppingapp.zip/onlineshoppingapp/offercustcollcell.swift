//
//  offercustcollcell.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 12/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class offercustcollcell: UICollectionViewCell {
    
    @IBOutlet weak var laboff: UILabel!
    @IBOutlet weak var offerimg: UIImageView!
}
