//
//  searchview.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 05/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class searchview: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate {
   
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var searchout: UISearchBar!
    let searcharr = [["catname":"mans wear","catid":"1"],
                     ["catname":"womans wear","catid":"2"],
        ["catname":"laptos","catid":"3"],
        ["catname":"mobile","catid":"4"],
        ["catname":"electonics","catid":"5"],
        ["catname":"cosmatics","catid":"6"],
        ["catname":"keyboards","catid":"7"],
        ["catname":"Decoration","catid":"8"]]
    
    var searchenabled = false
    var searesult : [[String:String]] = []
    
    
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchenabled == true
        {
            return searesult.count
        }
        else
        {
            return searcharr.count
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if searchenabled == true
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            
            let dic = searesult[indexPath.row]
            
            cell.textLabel?.text = dic["catname"]
            
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            let dic = searcharr[indexPath.row]
            
            cell.textLabel?.text = dic["catname"]
            
            return cell
        }
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.characters.count == 0
        {
            searchenabled = false
            tbl.reloadData()
        }
        else{
            searchenabled = true
            self.filter(searchtext: searchText)
            
        }
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        searchenabled = false
        searchBar.text = ""
        self.filter(searchtext: searchBar.text!)
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        searchenabled = true
        self.filter(searchtext: searchBar.text!)
    }
    func filter(searchtext:String) {
        
      
        
        let pradict = NSPredicate(format: "self.catname contains[c] %@",searchtext )
        
        searesult = searcharr.filter({ pradict.evaluate(with: $0)
            
        })
        tbl.reloadData()
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if searchenabled == true
        {
            let str = self.storyboard?.instantiateViewController(withIdentifier: "product")as! productviewcontroller
            self.navigationController?.pushViewController(str, animated: true)
        }
        else
        {
            let str = self.storyboard?.instantiateViewController(withIdentifier: "product")as! productviewcontroller
            self.navigationController?.pushViewController(str, animated: true)
       
    }
    
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


}
