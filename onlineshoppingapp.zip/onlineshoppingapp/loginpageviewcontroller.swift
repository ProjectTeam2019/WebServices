//
//  loginpageviewcontroller.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 01/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class loginpageviewcontroller: UIViewController {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var txtpass: UITextField!
    @IBOutlet weak var txtmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func regaction(_ sender: Any) {
        
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "reg");
        
        self.navigationController?.pushViewController(stb! , animated: true);
        
        
        
        
    }
    @IBAction func login(_ sender: Any) {
        
        let strurl = String("http://localhost/onlineshop/login.php?email=\(txtmail.text!)&password=\(txtpass.text!)")
        let url = URL(string:strurl)
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        
        
        let datatask = session.dataTask(with: request) { (data1, res, err) in
            
            
            DispatchQueue.main.async {
                
                let data = String(data: data1!, encoding: String.Encoding.utf8)
                print(data!)
                do
                {
                    let arr = try JSONSerialization.jsonObject(with: data1!, options: [])as! [Any]
                   if arr.count == 1
                   {
                    
                    
                    let strpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true);
                    
                    let path = strpath[0];
                    
                    let strfullpath = path.appending("/login.plist");

                    
                    let file = FileManager();
                    
                    if !file.fileExists(atPath: strfullpath)
                    {
                        
                        let dic :[String:Any] = ["record":arr];
                        let dic1 = NSDictionary(dictionary: dic);
                       
                    dic1.write(toFile: strfullpath, atomically: true)
                       
                        let stb = self.storyboard?.instantiateViewController(withIdentifier: "onlinetabbar");
                        
                        self.navigationController?.pushViewController(stb!, animated: true);
                        
                     
                       
                        
                    }
                    
                    
                    print(arr)
                   }
                        else
                        {
                            
                    }

                }
                catch
                {
                    
                }
            }
            
        }
        
        datatask.resume()
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
