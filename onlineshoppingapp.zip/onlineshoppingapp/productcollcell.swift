//
//  productcollcell.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 15/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class productcollcell: UICollectionViewCell {
    
    @IBOutlet weak var proprice: UILabel!
    @IBOutlet weak var proname: UILabel!
    @IBOutlet weak var proimg: UIImageView!
}
