//
//  detailcusttabcell5.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 18/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class detailcusttabcell5: UITableViewCell {

    @IBOutlet weak var lab3: UILabel!
    @IBOutlet weak var lab1: UILabel!
    
    @IBOutlet weak var moreinfo: UIButton!
    @IBOutlet weak var lab2: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
