//
//  dbclass.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 08/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class dbclass: NSObject {

    func dml(   strquery :String)->Bool  {
        
        
        var st :Bool = false;
        
        let path  = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let fullpath = path[0] ;
        let finalpath = fullpath.appending("/shop.db");
        
        print(finalpath);
        
        var db:OpaquePointer? = nil;
        
        if sqlite3_open(finalpath, &db) == SQLITE_OK {
            
            
            var stmt:OpaquePointer? = nil;
            
            if sqlite3_prepare_v2(db, strquery, -1, &stmt, nil) == SQLITE_OK
            {
                
                sqlite3_step(stmt);
                
                st = true;
                
                sqlite3_finalize(stmt);
                sqlite3_close(db);
                
            }
            
            
            
        }
        
        return st;
        
        
        
        
    }
    
    func getdata(strquery:String) -> [Any] {
    
        
        var finalarr :[Any] = [];
        
      
        
        let path  = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let fullpath = path[0] ;
        let finalpath = fullpath.appending("/shop.db");
        
        print(finalpath);
        
        var db:OpaquePointer? = nil;
        
        if sqlite3_open(finalpath, &db) == SQLITE_OK {
            
            
            var stmt:OpaquePointer? = nil;
            
            if sqlite3_prepare_v2(db, strquery, -1, &stmt, nil) == SQLITE_OK
            {
                
               while sqlite3_step(stmt) == SQLITE_ROW
               {
                
                var temp:[String] = [];
                let p_id = String(cString: sqlite3_column_text(stmt, 0));
                
                let p_name = String(cString: sqlite3_column_text(stmt, 1));
                
                let p_price = String(cString: sqlite3_column_text(stmt, 2));
                 let p_img = String(cString: sqlite3_column_text(stmt, 3));
                
                
                let p_qty = String(cString: sqlite3_column_text(stmt, 4));
                
                temp.append(p_id);
                temp.append(p_name);
                temp.append(p_price);
                temp.append(p_img);
                temp.append(p_qty);
                
                
                
                finalarr.append(temp);
                
                
                }
                
              
                
                sqlite3_finalize(stmt);
                sqlite3_close(db);
                
            }
            
            
            
        }
        
        return finalarr;
        
        
        
        
    }
   
    
    
    
    ////wishlist
    func getdatawish(strquery:String) -> [Any] {
        
        
        var finalarr :[Any] = [];
        
        
        
        let path  = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let fullpath = path[0] ;
        let finalpath = fullpath.appending("/shop.db");
        
        print(finalpath);
        
        var db:OpaquePointer? = nil;
        
        if sqlite3_open(finalpath, &db) == SQLITE_OK {
            
            
            var stmt:OpaquePointer? = nil;
            
            if sqlite3_prepare_v2(db, strquery, -1, &stmt, nil) == SQLITE_OK
            {
                
                while sqlite3_step(stmt) == SQLITE_ROW
                {
                    
                    var temp:[String] = [];
                    let w_id = String(cString: sqlite3_column_text(stmt, 0));
                    
                    let w_name = String(cString: sqlite3_column_text(stmt, 1));
                    
                    let w_price = String(cString: sqlite3_column_text(stmt, 2));
                    let w_img = String(cString: sqlite3_column_text(stmt, 3));
                    
                    
                    //let p_qty = String(cString: sqlite3_column_text(stmt, 4));
                    
                    temp.append(w_id);
                    temp.append(w_name);
                    temp.append(w_price);
                    temp.append(w_img);
                    //temp.append(p_qty);
                    
                    
                    
                    finalarr.append(temp);
                    
                    
                }
                
                
                
                sqlite3_finalize(stmt);
                sqlite3_close(db);
                
            }
            
            
            
        }
        
        return finalarr;
        
        
        
        
    }
    
}
