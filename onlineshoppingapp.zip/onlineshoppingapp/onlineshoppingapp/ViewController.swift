//
//  ViewController.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 04/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var time = Timer()
    var a = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        time = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.test), userInfo: nil, repeats: true)
        
        let st = self.storyboard?.instantiateViewController(withIdentifier: "login")
        self.navigationController?.pushViewController(st!, animated: true)
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    @objc func test(sender:Timer)  {
        if a <= 100 {
            a += 1
        }
        else
        {
            time.invalidate()
            
        }
    }

}

