//
//  homeview.swift
//  onlineshoppingapp
//
//  Created by MAC2 on 05/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit
import ImageSlideshow

class homeview: UIViewController,UITableViewDataSource,UITableViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
   
    var menubar = [
        ["menubarimg":"home.png","menubarname":"Home"],
    ["menubarimg":"search.png","menubarname":"Shop by categary"],
    ["menubarimg":"ofeer2.jpeg","menubarname":"Todays Deals"],
    ["menubarimg":"cart.png","menubarname":"Your Order"],
    ["menubarimg":"wish.png","menubarname":"Your Wishlist"],
    ["menubarimg":"profile.png","menubarname":"Your Account"],
    ["menubarimg":"ofeer5.jpeg","menubarname":"Gift Carts"],
    ["menubarimg":"profile.png","menubarname":"Customer Searvice"]]
   
    let menubarimg = ["home.png","search.png",""]
    
    var menutbl = UITableView()
    var v = UIView()
    let obj = commonfile()
    let imgarr = ["6.jpeg","5.jpeg","4.jpeg","2.jpeg","ww.png","6.jpeg","5.jpeg","4.jpeg","2.jpeg","ww.png","6.jpeg","5.jpeg","4.jpeg","2.jpeg","ww.png"]
    let offerimgs = [["offimage":"images.png","labname":"NEWOFFER"],
    ["offimage":"offer1.jpeg","labname":"NEWOFFER"],
    ["offimage":"ofeer2.jpeg","labname":"NEWOFFER"],
    ["offimage":"offer3.png","labname":"NEWOFFER"],["offimage":"offer4.jpeg","labname":"NEWOFFER"],
    ["offimage":"ofeer5.jpeg","labname":"NEWOFFER"],
   ["offimage":"offer7.png","labname":"NEWOFFER"],
    ["offimage":"offer8.png","labname":"NEWOFFER"],
     ["offimage":"offer9.jpeg","labname":"NEWOFFER"],
     ["offimage":"offer10.png","labname":"NEWOFFER"],
     ["offimage":"offer13.jpeg","labname":"NEWOFFER"],
    
     ["offimage":"offer14.jpeg","labname":"NEWOFFER"],
     ["offimage":"offer17.png","labname":"NEWOFFER"],
     ["offimage":"offer6.png","labname":"NEWOFFER"],
     ["offimage":"offer11.png","labname":"NEWOFFER"]]
    
   
    
    @IBOutlet weak var tbl: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
     craetesrc()
        
        
        
        let strpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true);
        
        let path = strpath[0];
        
        let strfullpath = path.appending("/login.plist");
        
        
        let file = FileManager();
        
        if file.fileExists(atPath: strfullpath)
        {
            let dic = ["menubarimg":"profile.png","menubarname":"Logout"];
          menubar.append(dic)
        }
        else
        
        {
            let dic = ["menubarimg":"profile.png","menubarname":"Login"];
            menubar.append(dic)
        }
        
      
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        createnav()
        
        menutbl = UITableView(frame: CGRect(x: -250, y: 0, width:200, height: self.view.frame.size.height), style: .grouped)
        menutbl.backgroundColor = UIColor.lightGray
        menutbl.delegate = self
        menutbl.dataSource = self
        menutbl.tag = 100
        self.view.addSubview(menutbl)
        
    v = UIView(frame:self.view.bounds)
        v.backgroundColor = UIColor.darkGray
        v.alpha = 0.0
        self.view.addSubview(v)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.tap))
        tap.numberOfTapsRequired = 1
        v.isUserInteractionEnabled  = true
        v.addGestureRecognizer(tap)
        
        
    }
    @objc func tap(sender:UITapGestureRecognizer)   {
        
        v.alpha = 0.0
        UITableView.beginAnimations(nil, context: nil)
        UITableView.setAnimationDuration(0.5)
        menutbl.frame = CGRect(x: -250, y: 0, width: 250, height: self.view.frame.size.height)
        
        //self.view.addSubview(menutbl)
    }
    func createnav()  {
   let navbar =  obj.createnav(fram: CGRect(x: 0, y: 30, width: self.view.frame.size.width, height: 60))
        
        let navitem = UINavigationItem()
        
        let menu = UIBarButtonItem(image: UIImage(named: "menu"), landscapeImagePhone: UIImage(named: "menu"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.menu))
        
        let search   = UIBarButtonItem(image: UIImage(named: "search"), landscapeImagePhone: UIImage(named: "search"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.search))
        
        
        navbar.items = [navitem]
        navitem.leftBarButtonItem = menu
        navitem.rightBarButtonItem = search
        self.view.addSubview(navbar)
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        if menutbl.tag == 100
        {
        return 1
        }
        else
        {
            return 4
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if menutbl.tag == 100
        {
            return menubar.count
        }
        else
        {
        return 1
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if menutbl.tag == 100
        {
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "menubar")
            let cell = tableView.dequeueReusableCell(withIdentifier: "menubar", for: indexPath)
            let dic = menubar[indexPath.row]
            
        cell.textLabel?.text = dic["menubarname"]
            cell.imageView?.image  = UIImage(named: dic["menubarimg"]!)
            
            let header = UIView(frame: CGRect(x: 20, y: 60, width: 60, height: 60))
            let userImage = UIImageView(frame:CGRect(x: 0, y: 0, width: 40, height: 40))
            //  userImage.image = UIImage(named: "search.png")
            userImage.layer.cornerRadius = 10
            header.addSubview(userImage)
            
            tableView.addSubview(cell)
           self.view.addSubview(tableView)
           cell.addSubview(header)
        return cell
        }
        else
        {
        
        if indexPath.section == 0
        {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! imageslidecusttab
    
        cell.imgslider.setImageInputs([
            ImageSource(image: UIImage(named: "5.jpeg")!),
            ImageSource(image: UIImage(named: "4.jpeg")!),
            ImageSource(image: UIImage(named: "2.jpeg")!),
              ImageSource(image: UIImage(named: "6.jpeg")!),
            ImageSource(image: UIImage(named: "ww.png")!)])
        
        cell.imgslider.slideshowInterval = 3.0
        cell.imgslider.zoomEnabled = true
        cell.imgslider.circular = true
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.didTap))
        cell.imgslider.addGestureRecognizer(gestureRecognizer)
        
        return cell
    }
        else if indexPath.section == 1
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)as! offercusttabcell
            cell.custcoll.reloadData()
            return cell
        
        }
        else if indexPath.section == 2
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath)as! bannercusttabcell
            cell.bannerimg.image = UIImage(named: "tt.jpeg")
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)as! offercusttabcell
            cell.custcoll.reloadData()
            return cell
        }
      }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if menutbl.tag == 100
        {
            return 50
        }
        else
        {
      if indexPath.section  == 0
      {
        return 200
        }
      else if indexPath.section == 1
      {
        return 200
        }
        else if indexPath.section == 2
      {
        return 200
        }
        else
      {
        return 200
        }
    }
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if menutbl.tag == 100
        {
            return "hello"
        }
        else
        {
      if   section == 1
        {
            return " LIMITED OFFERS"
        }
        else if section == 2
      {
        return "Todays OfferS"
        }
        else  if section == 3
      {
        return  "COMMING S00N..."
        }
        else
      {
        return ""
        }
    }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if menutbl.tag == 100
        {
            
            let strdata = menubar[indexPath.row];
            
            let name =  strdata["menubarname"];
            
            if name == "Login"
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "login");
                self.navigationController?.pushViewController(stb!, animated: true);
                
                
            }
            else if name == "Logout"
            {
                
                let strpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true);
                
                let path = strpath[0];
                
                let strfullpath = path.appending("/login.plist");
                
                
                let file = FileManager();
                
                do
                {
                 try file.removeItem(atPath: strfullpath)
                    
                    let dic = ["menubarimg":"profile.png","menubarname":"Login"];
                    menubar.remove(at: 8);
                    
                    menubar.append(dic)
                    
                  //  tbl.reloadData();
                    
                }
                catch
                {
                    
                }
                
            }
            else
                
            {
                
                
            }
            
            
            
        }
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if menutbl.tag == 100
        {
        let header = UIView(frame: CGRect(x: 20, y: 60, width: 60, height: 60))
        let userImage = UIImageView(frame:CGRect(x: 0, y: 0, width: 40, height: 40))
          //  userImage.image = UIImage(named: "search.png")
            userImage.layer.cornerRadius = 10
            header.addSubview(userImage)
            
            tableView.addSubview(header)
            return header
    }
        else
        {
            let v = UIView()
            return v
            
        }
    }
    
  
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imgarr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "coll", for: indexPath)as!offercustcollcell
        
        let dic = offerimgs[indexPath.row]
        
        
        
        cell.offerimg.image = UIImage(named: dic["offimage"]! )
        cell.laboff.text = dic["labname"]
        return cell
        
    }
    @objc func didTap() {
        
        let indexpath = IndexPath(row: 0, section: 0)
        let cell = tbl.cellForRow(at: indexpath) as! imageslidecusttab
        cell.imgslider.presentFullScreenController(from: self)
    }
    func craetesrc()  {
        
        let src = UIScrollView()
        src.frame = self.view.frame
        src.contentSize = CGSize(width: self.view.frame.width, height: 1000)
    self.view.addSubview(src)
        src.addSubview(tbl)
        
    }
        
    @objc func menu(sender:UIBarButtonItem)  {
        v.alpha = 0.5
    UITableView.beginAnimations(nil, context: nil)
        UITableView.setAnimationDuration(0.5)
        menutbl.frame = CGRect(x: 0, y: 0, width: 250, height: self.view.frame.size.height)
        UITableView.commitAnimations()
        self.view.addSubview(menutbl)
        
    
    }
   
    @objc func search(sender:UIBarButtonItem)  {
        tabBarController?.selectedIndex = 1
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
