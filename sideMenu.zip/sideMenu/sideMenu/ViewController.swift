
import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UINavigationControllerDelegate
{
    
    @IBOutlet weak var tbl: UITableView!
    var menubar = [
        ["menubarimg":"delete.png","menubarname":"Delete"],
        ["menubarimg":"face.png","menubarname":"Face"],
        ["menubarimg":"wish.png","menubarname":"Wish"]]
    
    let menubarimg = ["home.png","search.png",""]
    var menutbl = UITableView()
    var v = UIView()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
       
        let strpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true);
        
        let path = strpath[0];
        
        let strfullpath = path.appending("/login.plist");
        
        
        let file = FileManager();
        
        if file.fileExists(atPath: strfullpath)
        {
            let dic = ["menubarimg":"profile.png","menubarname":"Logout"];
            menubar.append(dic)
        }
        else
            
        {
            let dic = ["menubarimg":"profile.png","menubarname":"Login"];
            menubar.append(dic)
        }
    }

    override func viewDidAppear(_ animated: Bool)
    {
        createnav()

        menutbl = UITableView(frame: CGRect(x: -250, y: -30, width:200, height: self.view.frame.size.height), style: .grouped)
        menutbl.backgroundColor = UIColor.lightGray
        menutbl.delegate = self
        menutbl.dataSource = self
        menutbl.tag = 100
        self.view.addSubview(menutbl)
        
        v = UIView(frame:self.view.bounds)
        v.backgroundColor = UIColor.darkGray
        v.alpha = 0.0
        self.view.addSubview(v)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.tap))
        tap.numberOfTapsRequired = 1
        v.isUserInteractionEnabled  = true
        v.addGestureRecognizer(tap)
    }
    
    func createnav()
    {
        
        let navbar = UINavigationBar()
        navbar.frame = CGRect(x: 0, y: 30, width: self.view.frame.size.width, height: 60)
        let navitem = UINavigationItem()
        
        let menu = UIBarButtonItem(image: UIImage(named: "menu"), landscapeImagePhone: UIImage(named: "menu"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.menu))
        
        let search   = UIBarButtonItem(image: UIImage(named: "search"), landscapeImagePhone: UIImage(named: "search"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.search))
        
        
        navbar.items = [navitem]
        navitem.leftBarButtonItem = menu
        navitem.rightBarButtonItem = search
        self.view.addSubview(navbar)
        
    }
    
    @objc func menu()
    {
        v.alpha = 0.5
        UITableView.beginAnimations(nil, context: nil)
        UITableView.setAnimationDuration(0.5)
        menutbl.frame = CGRect(x: 0, y: -30, width: 250, height: self.view.frame.size.height)
        UITableView.commitAnimations()
        self.view.addSubview(menutbl)
    }
    @objc func search()
    {
        
    }
    
    @objc func tap(sender:UITapGestureRecognizer)
    {
        v.alpha = 0.0
        UITableView.beginAnimations(nil, context: nil)
        UITableView.setAnimationDuration(0.5)
        menutbl.frame = CGRect(x: -250, y: 0, width: 250, height: self.view.frame.size.height)
        
        //self.view.addSubview(menutbl)
    }
    
    @IBAction func click(_ sender: Any)
    {
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if menutbl.tag == 100
        {
            return menubar.count
        }
        else
        {
            return 1
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        if menutbl.tag == 100
        {
            return 1
        }
        else
        {
            return 4
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        /*if menutbl.tag == 100
        {*/
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "menubar")
            let cell = tableView.dequeueReusableCell(withIdentifier: "menubar", for: indexPath)
            let dic = menubar[indexPath.row]
            
            cell.textLabel?.text = dic["menubarname"]
            cell.imageView?.image  = UIImage(named: dic["menubarimg"]!)
            
            let header = UIView(frame: CGRect(x: 20, y: 60, width: 60, height: 60))
            let userImage = UIImageView(frame:CGRect(x: 0, y: 0, width: 40, height: 40))
            //  userImage.image = UIImage(named: "search.png")
            userImage.layer.cornerRadius = 10
            header.addSubview(userImage)
            
            tableView.addSubview(cell)
            self.view.addSubview(tableView)
            cell.addSubview(header)
            return cell
        //}
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if menutbl.tag == 100
        {
            return 50
        }
        else
        {
            if indexPath.section  == 0
            {
                return 200
            }
            else if indexPath.section == 1
            {
                return 200
            }
            else if indexPath.section == 2
            {
                return 200
            }
            else
            {
                return 200
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if menutbl.tag == 100
        {
            
            let strdata = menubar[indexPath.row];
            
            let name =  strdata["menubarname"];
            
            if name == "Login"
            {
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "login");
                self.navigationController?.pushViewController(stb!, animated: true);
                
                
            }
            else if name == "Logout"
            {
                
                let strpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true);
                
                let path = strpath[0];
                
                let strfullpath = path.appending("/login.plist");
                
                
                let file = FileManager();
                
                do
                {
                    try file.removeItem(atPath: strfullpath)
                    
                    let dic = ["menubarimg":"profile.png","menubarname":"Login"];
                    menubar.remove(at: 8);
                    
                    menubar.append(dic)
                    
                    //  tbl.reloadData();
                    
                }
                catch
                {}
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        if menutbl.tag == 100
        {
            let header = UIView(frame: CGRect(x: 20, y: 60, width: 60, height: 60))
            let userImage = UIImageView(frame:CGRect(x: 0, y: 0, width: 40, height: 40))
            //  userImage.image = UIImage(named: "search.png")
            userImage.layer.cornerRadius = 10
            header.addSubview(userImage)
            
            tableView.addSubview(header)
            return header
        }
        else
        {
            let v = UIView()
            return v
        }
    }

    
    
    
}

