<?php
    
    $con=new mysqli("localhost","root","","votingdb");
    
    $data = file_get_contents('php://input');
    $dt = json_decode($data);
    
    $user_fname = $dt->user_fname;
     $user_lname = $dt->user_lname;
    $user_email = $dt->user_email;


    define('UPLOAD_DIR', 'images/');
    $img = $dt->image;
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    
    $q = "Update tbluserreg set user_fname = '$user_fname',user_lname = '$user_lname',user_email = '$user_email', image = '$file'";
    $con->query($q);

    $q1 = "select * from tbluserreg";

    $res = $con->query($q1);
    $row[] = $res->fetch_assoc();
    echo json_encode($row);
?>
