<?php
	
    $con=new mysqli("localhost","root","","votingdb");
  
    $data=file_get_contents('php://input');
    
    $dt = json_decode($data);
  
    
   // $E_name = $dt->E_name;
    //$Starting_date = $dt->Starting_date;
    //$Ending_date = $dt->Ending_date;
    //$Status = $dt->Status;
    
    /*define('UPLOAD_DIR', 'images/');
    
    $img = $dt->Banner_image;
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    
    $query = "insert into tbl_voting_zone(E_name,Banner_image)values('$E_name','$file')";
    $con->query($query);
  
    echo "success"*/
?>
