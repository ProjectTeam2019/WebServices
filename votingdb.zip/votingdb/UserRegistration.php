<?php
	
    $con=new mysqli("localhost","root","","votingdb");
  
    $data=file_get_contents('php://input');
    
    $dt = json_decode($data);
  
    $user_email = $dt->user_email;
    $user_fname = $dt->user_fname;
    $user_lname = $dt->user_lname;
    $user_password = $dt->user_password;
    $user_type = $dt->user_type;
    
    define('UPLOAD_DIR', 'images/');
    
    $img = $dt->image;
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    
    $query = "insert into tbluserreg(user_email,user_fname,user_lname,user_password,user_type,image)values('$user_email','$user_fname','$user_lname','$user_password','$user_type','$file')";
    $con->query($query);
  
    echo "success"
?>

