<?php
	
    $con=new mysqli("localhost","root","","votingdb");
  
    $data=file_get_contents('php://input');
    
    $dt = json_decode($data);
  
    
   // $E_name = $dt->E_name;
    $Start_time = $dt->Start_time;
    $End_time = $dt->End_time;
    //$Status = $dt->Status;
    
    /*define('UPLOAD_DIR', 'images/');
    
    $img = $dt->Banner_image;
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    */
    $query = "insert into tbl_voting_manager(Start_time,End_time)values('$Start_time','$End_time')";
    $con->query($query);
  
    echo "success"
?>
