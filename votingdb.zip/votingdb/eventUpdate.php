<?php
	
    $con=new mysqli("localhost","root","","votingdb");
  
    $data=file_get_contents('php://input');
    
    $dt = json_decode($data);
  
    
    $Starting_date = $dt->Starting_date;
    $Ending_date = $dt->Ending_date;
    //$Status = $dt->Status;
    
    /*define('UPLOAD_DIR', 'images/');
    
    $img = $dt->Banner_image;
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    */
    $query = "update table Tbl_Event_master set Starting_date = '$Starting_date' Ending_date  = '$Ending_date'";
    $con->query($query);
  
    echo "success"
?>

