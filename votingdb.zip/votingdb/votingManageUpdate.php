<?php
    
    $con=new mysqli("localhost","root","","votingdb");
    
    $data=file_get_contents('php://input');
    
    $dt = json_decode($data);
    
    
    $u_id = $dt->u_id;
    
   
    $query = "update table tbl_voting_manager set u_id = '$u_id'";
    $con->query($query);
    
    echo "success"
    ?>


