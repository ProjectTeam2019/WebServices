<?php
	
    $con=new mysqli("localhost","root","","votingdb");
    
    $user_email = $_REQUEST["user_email"];
    $user_password = $_REQUEST["user_password"];
 
    $qu = mysqli_query($con,"select * from tbluserreg where user_email = '$user_email' and user_password = '$user_password'");
    if(mysqli_num_rows($qu) == 0){
        $row = array();
        
        print_r(json_encode($row));
    }
    else
    {
        while($row = mysqli_fetch_assoc($qu))
        {
            $pp[]  = $row;
        }
        echo json_encode($pp);
    }
?>

